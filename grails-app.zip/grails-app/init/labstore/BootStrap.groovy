package labstore


class BootStrap {

    def init = { servletContext ->

    }
    def destroy = {
    }
}
